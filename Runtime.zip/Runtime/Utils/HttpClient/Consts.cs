namespace DynamicPixels.GameService.Utils.HttpClient
{
    internal enum WebRequestMethod
    {
        Get,
        Post,
        Put,
        Delete
    }
}