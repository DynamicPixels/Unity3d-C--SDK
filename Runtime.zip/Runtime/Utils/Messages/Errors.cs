namespace DynamicPixels.GameService.Utils.Messages
{
    public class Errors
    {
        public const string InvalidBody = "request body is invalid/json";
        public const string ConnectionError = "cant connect to server";

    }
}