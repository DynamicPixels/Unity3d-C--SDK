namespace DynamicPixels.GameService.Services.Device.Models
{
    public class FindMyDeviceParams
    {
        
    }

    public class RevokeDeviceParams
    {
        public int DeviceId { get; set; }
    }
}