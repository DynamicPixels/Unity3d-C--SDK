namespace DynamicPixels.GameService.Services.Storage.Repositories
{
    public class UrlMap
    {
        public static string GetUploadFileUrl = "/api/storage/upload";

    }
}