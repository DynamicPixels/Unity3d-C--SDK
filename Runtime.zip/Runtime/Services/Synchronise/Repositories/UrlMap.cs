namespace DynamicPixels.GameService.Services.Synchronise.Repositories
{
    public class UrlMap
    {
        public static string GetServerTimeUrl = $"/api/synchronise/time";
    }
}