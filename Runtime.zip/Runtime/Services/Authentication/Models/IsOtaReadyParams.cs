using System;

namespace DynamicPixels.GameService.Services.Authentication.Models
{
    [Serializable]
    public class IsOtaReadyParams
    {
        
    }
}