namespace DynamicPixels.GameService.Models.inputs
{
    public enum Order
    {
        ASC,
        DESC
    }
    
}